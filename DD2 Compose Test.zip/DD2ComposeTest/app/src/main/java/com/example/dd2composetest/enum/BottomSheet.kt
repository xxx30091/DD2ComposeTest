package com.example.dd2composetest.enum

enum class BottomSheet(val route: String) {
    ADD_USER_TAG("add_user_tag"),
    ADD_TOPIC("add_topic"),
    ADD_ARTICLE("add_article")
}