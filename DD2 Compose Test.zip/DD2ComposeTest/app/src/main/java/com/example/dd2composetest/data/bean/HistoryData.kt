package com.example.dd2composetest.data.bean

data class HistoryData(
//    val id: Int = 0,
    val unlockCount: Int = 0,
    val increaseFans: Int = 0,
    val date: String = "",
    val cost: String = "",
    val videoCount: Int = 0
)
