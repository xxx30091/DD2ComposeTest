package com.example.dd2composetest.data.bean

data class VideoPromoteData(
    val cost: Int = 0,
    val percentage: Int = 0,
    val location: String = "",
    val endDate: String = "",
    val status: String = ""
)
