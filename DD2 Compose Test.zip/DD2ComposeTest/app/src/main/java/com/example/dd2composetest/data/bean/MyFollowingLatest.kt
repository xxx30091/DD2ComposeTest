package com.example.dd2composetest.data.bean

data class MyFollowingLatest(
    var video: MyFollowingVideo,
    var topic: MyFollowingTopic,
    var article: MyFollowingArticle
)
